const request = require('supertest');
const app = require('../routes/empleados.routes'); // ajusta según tu estructura

//FUNCIONAL
describe('GET /empleados', function() {
  it('Codigo 200 Lista de empleados', 
    function(){
        request(app)
        .get('/empleados')
        .set('Acept', 'application/json')
        .expect('Content-Type', '/json')
        .expect(200)
    }
  );
});

//CON ERROR
describe('GET /empleados', function() {
  it('Error 404 Empleado no existe', 
    function(){
        request(app)
        .get('/empleados/200')
        .set('Acept', 'application/json')
        .expect('Content-Type', '/json')
        .expect(404)
        .expect('Empleado no encontrado')
    }
  );
});

//POST 
describe('POST /empleados', ()=> {
  it('Codigo 200 Creacion usuario', () =>{
    const data={
        nombre:"Pedro Torres",
        cargo:"Contador",
        departamento:"contabilidad",
        sueldo:'1000'
    }
    request(app)
    .post('/empleados')
    .send(data)
    .set('Acept', 'application/json')
    .expect('Content-Type', '/json')
    .expect(200)
  }
  );
});


//POST 
describe('POST /empleados', ()=> {
  it('Error de creacion 404', () =>{
    const data={}
    request(app)
    .post('/empleados')
    .send(data)
    .set('Acept', 'application/json')
    .expect('Content-Type', '/json')
    .expect(404)
  }
  );
});